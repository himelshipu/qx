<?php

namespace App\View\Components\frontend\partials;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class Cases extends Component
{
    public function __construct()
    {
        //
    }

    public function render(): View|Closure|string
    {
        return view('components.frontend.partials.cases');
    }
}
